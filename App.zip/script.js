function goTo(id) {
    document.querySelectorAll(".screen").forEach(screen => {
        screen.classList.remove("active");
    });

    const screen = document.getElementById(id);

    if (screen) {
        screen.classList.add("active");
    }
}

window.addEventListener("load", () => {

    if (sessionStorage.getItem("returnToGender") === "true") {

        sessionStorage.removeItem("returnToGender");
        goTo("s4");

    } else {

        if (!sessionStorage.getItem("visited")) {

            sessionStorage.setItem("visited", "true");

            setTimeout(() => {
                goTo("s2");
            }, 2000);

        } else {

            goTo("s2");

        }

    }

});

function pick(gender) {

    document.querySelectorAll(".card").forEach(card => {
        card.classList.remove("selected");
    });

    document.getElementById(gender).classList.add("selected");

    sessionStorage.setItem("returnToGender", "true");

    setTimeout(() => {

        if (gender === "male") {
            window.location.href = "male.html";
        } else {
            window.location.href = "female.html";
        }

    }, 300);

}

function pickGoal(cardId, nextScreen) {

    document.querySelectorAll(".goal-card").forEach(card => {
        card.classList.remove("selected");
    });

    document.getElementById(cardId).classList.add("selected");

    setTimeout(() => {
        goTo(nextScreen);
    }, 300);

}

function goBackToGender() {
    sessionStorage.setItem("returnToGender", "true");
    window.location.href = "index.html";
}